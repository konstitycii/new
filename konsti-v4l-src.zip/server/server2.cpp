#include <unistd.h>
#include <thread>
#include <mutex>
#include <deque>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <linux/videodev2.h>
#include <math.h>
#include <typeinfo>
#include <iostream>
#include <pthread.h>
#include <linux/i2c.h>
#include <sys/ioctl.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <cstring> // memset()

#include <cstring>
#include <vector>

extern "C" {
#include "v4l2uvc.h"
}

using namespace std;

const int FMT = V4L2_PIX_FMT_YUYV; //V4L2_PIX_FMT_SGRBG8; // формат поддерживаемый матрицей
const unsigned default_port = 3425; // порт, по которому будет стучаться клиент
const int number_of_seconds = 5;   // кол-во секунд, что сервер будет хранить в памяти
const char* dev_name = "/dev/video0";
const double default_fps = 10;      // должно совпадать с таким же значением из client.cpp
                                    // если резуьтирующее видео "быстрое", то камера не выдает такой фрейм рейт

int WIDTH = 1920; // ширина
int HEIGHT = 1080; // и высота текущего видео захвата
deque<string> q;  // очередь с кадрами
mutex qmutex;  // мьютекс для охраны очереди
int working = 0;

// тред, в котором идет накопление захваченных кадров в памяти
void video_grabber_thread() {
    cout << "[VIDEO_GRABBER] : start" << endl;

    vdIn videoIn;
    int rc = 0;

    rc = init_videoIn(&videoIn, dev_name, WIDTH, HEIGHT, FMT, 1);
    if (rc < 0) {
        exit(1);
    }

    rc = uvcGrab(&videoIn);
    if (rc < 0) {
        exit(1);
    }

    // получаем размеры доступной картинки 
    WIDTH  = videoIn.width;
    HEIGHT = videoIn.height;

    {
        // очищаем очередь перед началом работы
        lock_guard<mutex> lk(qmutex);
        q.clear();
    }

    // пока нам не дали команду завершить захват
    while (working) {
        // захватываем мьютекс охраняющий очередь с кадрами
        if (!qmutex.try_lock()) this_thread::sleep_for(5ms);

        // удаляем "старые" кадры
        while (q.size() >= number_of_seconds * default_fps) {
            q.pop_back();
        }

        // захватываем картинку
        rc = uvcGrab(&videoIn);
        if (rc < 0) break;

        // создаем матрицу из кадра

        string src((char*)videoIn.framebuffer, WIDTH * HEIGHT * 3);

        // добавляем его в очередь
        q.emplace_front(move(src));
        // разблокируем очередь
        qmutex.unlock();
    }
    close_v4l2(&videoIn);
    cout << "[VIDEO_GRABBER] : stop" << endl;
}

void send_queue(int sock) {
    lock_guard<mutex> lk(qmutex);
    uint32_t t = q.size();

    // пишем кол-во кадров
    send(sock, (char*) &t, sizeof(t), 0);
    // высоту
    t = HEIGHT;
    send(sock, (char*) &t, sizeof(t), 0);
    // и ширину кадра
    t = WIDTH;
    send(sock, (char*) &t, sizeof(t), 0);

    int rc = 0;
    while (!q.empty()) {
        // берем самый старый кадр
        auto & ref_mat = q.back();
        // вычисляем кол-во байт в нем
        uint32_t total = (ref_mat.size());
        // шлем это значение, чтобы клиент знал сколько
        // ему нужно вычитать байт этого кадра
        rc = send(sock, (char*) &total, sizeof(total), 0);
        cout << " total = " << total << endl;
        int sent = 0;
        while (total > 0) {
            // шлем непосредственно байты кадра
            rc = send(sock, ref_mat.data() + sent, total, 0);
            if (rc == -1) {
                cout << "errno=" << errno << endl;
                break;
            }
            sent  += rc;
            total -= rc;
            cout << " sent = " << sent << endl;
        }
        // удаляем обработанный кадр из очереди
        q.pop_back();
    }
}

int main() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        exit(1);
    }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(default_port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sock, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        perror("ERR: binding failed!");
        exit(2);
    }

    listen(sock, 1);

    for (;;) {
        // запускаем граббинг кадров в очередь
        // параллельно нашему треду
        working = 1;
        std::thread t(&video_grabber_thread);

        // а сами в этом треде ждем подключение клиента
        struct sockaddr_in client;
        socklen_t len = sizeof(struct sockaddr_in);
        int new_socket = accept(sock, (struct sockaddr *)&client, &len);

        // к нам подключились, тогда останавливаем граббинг видео
        working = 0;
        t.join();

        if (new_socket == -1) { // если подключения клиента нет, то...
            cerr << "ERR: new_socket = " << new_socket << endl;
            break;
        } else { //если подключился клиент, то ..
            send_queue(new_socket);
        }
    }

    close(sock); // закрытие сокета
    return 0;
}
